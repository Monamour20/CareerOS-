# Implementation Plan

1. Add a pure onboarding profile-builder module so UI state-to-CareerProfile mapping is testable.
2. Add a multi-step `AdaptiveOnboarding` component.
3. Select the question flow from the user's career status.
4. Keep the existing onboarding API contract unchanged.
5. Preserve the existing Career Vault persistence path.
6. Record the resume decision using the existing `resume_creation_requested` boolean.
7. If the user chooses `Upload now`, open the existing Resume Intelligence view after onboarding is saved.
8. Add unit tests for list parsing, conditional profile records, and resume decision mapping.
9. Run typecheck, tests, lint, and real onboarding integration verification after applying the package.
