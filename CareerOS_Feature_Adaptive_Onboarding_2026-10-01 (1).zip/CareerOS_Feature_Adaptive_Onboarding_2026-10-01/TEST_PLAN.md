# Test Plan

## Static

- `npm run typecheck`
- `npm run test`
- `npm run build`
- `npm run lint` (if the existing repository script works; the current package defines it as `next lint`)
- `pytest`
- `ruff check .`

## Frontend behavior

1. Sign up with a synthetic account.
2. Select Student and confirm the flow asks education/projects rather than forcing professional experience.
3. Select Working Professional in a fresh account and confirm experience fields appear.
4. Complete each branch and verify no empty records are persisted.
5. Try each resume choice.
6. For Upload now, confirm Resume Intelligence opens after save.
7. Reopen Career Vault and confirm the same information is present.

## Boundary / data checks

- Empty optional fields.
- One skill.
- Multiple comma/newline-separated skills.
- No experience for a student.
- No education for a professional who chooses not to enter it.
- Resume decision values map to the existing backend boolean.
