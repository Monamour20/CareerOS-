# Apply Instructions

## Before applying

1. Confirm the current checkout is based on commit `e6422dfdd1e7a9e4b93e1fc2075767c4e590783c`.
2. If `main` has moved, stop and re-audit/rebase this package.
3. Preserve the existing `urban happiness` Codespace changes; do not reset them as part of this package.

## Files

Copy the files under `CHANGES/new/` into the repository. Replace `apps/web/app/page.tsx` with the version under `CHANGES/modify/`. Copy the test under `TESTS/` to `apps/web/lib/onboarding.test.ts`.

## Important

Do not add a database migration. Do not change the onboarding API contract. Do not add an npm dependency.

## Verification after applying

Run the commands in `TEST_PLAN.md`. Repair any real environment failures before committing.
