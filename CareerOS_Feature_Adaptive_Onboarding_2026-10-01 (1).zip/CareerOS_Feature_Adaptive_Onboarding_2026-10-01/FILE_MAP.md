# File Map

## New

- `apps/web/components/onboarding/AdaptiveOnboarding.tsx` — multi-step adaptive onboarding UI.
- `apps/web/lib/onboarding.ts` — pure draft-to-CareerProfile mapping and resume-decision helpers.

## Modified

- `apps/web/app/page.tsx` — imports and renders `AdaptiveOnboarding`; removes the old single-form onboarding implementation.

## Tests

- `apps/web/lib/onboarding.test.ts` — unit tests for pure onboarding mapping.

## Backend

No backend files are intentionally changed in this feature.
