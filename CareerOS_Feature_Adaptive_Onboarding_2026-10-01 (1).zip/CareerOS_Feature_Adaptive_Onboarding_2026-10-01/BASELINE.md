# Baseline

## Git

`main` at `e6422dfdd1e7a9e4b93e1fc2075767c4e590783c`.

## Existing onboarding

- Backend endpoint: `POST /api/v1/onboarding/career-profile`
- Backend persistence is already verified.
- Existing frontend uses one large `Onboarding` form in `apps/web/app/page.tsx`.
- The existing form writes one placeholder-like entry into several profile arrays even when fields are empty.
- Resume handling currently stores only a boolean intent.

## Why this feature is next

The canonical workflow requires adaptive onboarding, but the current UI is a single long questionnaire. The repository verification document explicitly states that the adaptive multi-step UI and resume-driven onboarding experience are still pending.
