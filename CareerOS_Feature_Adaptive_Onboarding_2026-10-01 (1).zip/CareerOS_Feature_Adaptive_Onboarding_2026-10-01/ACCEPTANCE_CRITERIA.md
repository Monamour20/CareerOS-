# Acceptance Criteria

- [ ] A new user sees a multi-step onboarding flow instead of the previous giant form.
- [ ] Career status is selected before later questions are shown.
- [ ] The background step changes its focus based on career status.
- [ ] Education, experience, skills, projects, goals, preferences, and resume decision remain supported.
- [ ] Empty education/experience/project records are not created.
- [ ] Existing onboarding API request shape remains unchanged.
- [ ] Existing PostgreSQL persistence path remains unchanged.
- [ ] `Upload now` saves the onboarding data and opens Resume Intelligence.
- [ ] `Create later` saves onboarding without opening Resume Intelligence.
- [ ] `Continue without` saves onboarding with `resume_creation_requested=false`.
- [ ] Career Vault can retrieve the saved profile after completion.
- [ ] TypeScript typecheck passes.
- [ ] Frontend tests pass.
- [ ] Python tests and Ruff remain green.
- [ ] Manual end-to-end onboarding verification passes with a synthetic account.
